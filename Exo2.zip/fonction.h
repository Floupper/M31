float tirage();
int lancerDe();

void stockeLancer(float *tab, unsigned int n);
void affichageLancer(float *tab, unsigned int n);

void stockeTirage(float *tab, unsigned int n);
void affichageTirage(float *tab, unsigned int n);